module.exports=[26758,a=>{a.v("/_next/static/media/favicon.71bb13f9.ico")},38872,a=>{"use strict";let b={src:a.i(26758).default,width:213,height:213};a.s(["default",0,b])}];

//# sourceMappingURL=app_b9b1292a._.js.map
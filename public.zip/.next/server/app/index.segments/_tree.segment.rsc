:HL["/_next/static/chunks/613857ca43122d90.css","style"]
:HL["/_next/static/media/96d4d083aca4efcb-s.p.c31d9bed.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/c9f6ebf08ddd616b-s.p.8e1a882d.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"buildId":"ALaeDi3VwcnKgrnPJCaGg","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}

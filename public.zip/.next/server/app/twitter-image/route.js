var R=require("../../chunks/[turbopack]_runtime.js")("server/app/twitter-image/route.js")
R.c("server/chunks/[root-of-the-server]__4d013555._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_twitter-image_route_actions_3c56c007.js")
R.m(91433)
module.exports=R.m(91433).exports
